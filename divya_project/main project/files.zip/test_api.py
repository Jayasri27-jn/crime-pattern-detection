"""
test_api.py — Run this to test your API is working correctly.
Usage:  python test_api.py
        python test_api.py https://your-ngrok-url.ngrok-free.app
"""

import sys
import json
import urllib.request
import urllib.error

BASE_URL = sys.argv[1].rstrip('/') if len(sys.argv) > 1 else 'http://localhost:7860'

SAMPLE_INPUT = {
    "city":       "Delhi",
    "time":       "Night",
    "weather":    "rainy",
    "cctv":       2,
    "police":     1,
    "traffic":    7,
    "speed":      15,
    "temp":       32,
    "rainfall":   155,
    "accidents":  3,
    "complaints": 4,
}

def test_health():
    print(f"\n🔍 Testing: {BASE_URL}/health")
    try:
        req = urllib.request.urlopen(f"{BASE_URL}/health", timeout=10)
        data = json.loads(req.read())
        print(f"✅ Health check passed: {data}")
    except Exception as e:
        print(f"❌ Health check failed: {e}")

def test_predict():
    print(f"\n🔍 Testing: {BASE_URL}/predict")
    print(f"   Input: {json.dumps(SAMPLE_INPUT, indent=2)}")
    try:
        body = json.dumps(SAMPLE_INPUT).encode('utf-8')
        req  = urllib.request.Request(
            f"{BASE_URL}/predict",
            data=body,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        res  = urllib.request.urlopen(req, timeout=15)
        data = json.loads(res.read())
        print(f"✅ Prediction result:")
        print(f"   Severity Score : {data['predicted_severity']}")
        print(f"   Risk Level     : {data['risk_level']}")
        print(f"   Status         : {data['status']}")
    except Exception as e:
        print(f"❌ Prediction failed: {e}")

if __name__ == '__main__':
    print(f"🧪 Testing Crime Severity API at: {BASE_URL}")
    test_health()
    test_predict()
    print("\n✅ Tests complete.")
    print(f"\n📌 If tests passed, paste this URL in your dashboard:")
    print(f"   {BASE_URL}/predict")
