"""
run_setup.py — Run this ONCE before starting the app.
It installs all libraries and sets up your ngrok auth token.
"""

import subprocess
import sys

def install_libs():
    print("📦 Installing required libraries...")
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])
    print("✅ All libraries installed\n")

def setup_ngrok():
    token = input("🔑 Paste your ngrok auth token (from ngrok.com/your-authtoken): ").strip()
    if token:
        subprocess.check_call(['ngrok', 'config', 'add-authtoken', token])
        print("✅ ngrok configured\n")
    else:
        print("⚠️  Skipped ngrok setup. You can run manually:")
        print("   ngrok config add-authtoken YOUR_TOKEN\n")

if __name__ == '__main__':
    install_libs()
    setup_ngrok()
    print("🚀 Setup complete! Now run:  python crime_api.py")
