# Crime Pattern Detection — Project Setup Guide

## Project: Crime Pattern Detection using Geospatial and Temporal Analysis

---

## Files in this project

| File | Purpose |
|---|---|
| crime_api.py | Main file — ML model + Flask API + Gradio UI + ngrok |
| requirements.txt | All Python libraries needed |
| run_setup.py | One-time setup script (install libs + ngrok token) |
| test_api.py | Test script to verify API is working |
| crime_dataset.csv | YOUR dataset (copy it here) |
| crime_analysis_dashboard.html | Frontend dashboard (deploy to Netlify) |

---

## Step-by-Step Setup

### Step 1 — Prerequisites

Make sure Python 3.8+ is installed:
```
python --version
```

### Step 2 — Copy your dataset

Copy your crime_dataset.csv into this folder (same folder as crime_api.py).

Your CSV must have these columns (rename if different):
- city
- time  (Morning / Afternoon / Evening / Night / Midnight)
- weather  (sunny / cloudy / rainy / foggy / stormy)
- cctv
- police
- traffic
- speed
- temp
- rainfall
- accidents
- complaints
- severity

### Step 3 — One-time setup

```bash
python run_setup.py
```

This will:
- Install all required libraries
- Ask for your ngrok token (get it free at ngrok.com)

### Step 4 — Run the app

```bash
python crime_api.py
```

You will see:
```
✅ Model trained successfully
✅ Flask API  → http://localhost:7860
🌐 PUBLIC URL → https://abc123.ngrok-free.app
📌 Paste into dashboard: https://abc123.ngrok-free.app/predict
```

Keep this terminal open while using the dashboard!

### Step 5 — Test the API

Open a NEW terminal and run:
```bash
python test_api.py
```

Or test with your ngrok URL:
```bash
python test_api.py https://abc123.ngrok-free.app
```

### Step 6 — Deploy dashboard to Netlify

1. Go to: https://app.netlify.com/drop
2. Drag crime_analysis_dashboard.html onto the page
3. Get your public URL (e.g. https://brave-moon-abc.netlify.app)

### Step 7 — Connect dashboard to API

1. Open your Netlify dashboard URL
2. Go to the Predict tab
3. In API Endpoint field, paste:
   https://abc123.ngrok-free.app/predict
4. Click Predict Crime Severity

---

## Troubleshooting

| Problem | Fix |
|---|---|
| ModuleNotFoundError | Run: pip install -r requirements.txt |
| ngrok error | Run: ngrok config add-authtoken YOUR_TOKEN |
| Column not found error | Check your CSV column names match the rename_map in crime_api.py |
| CORS error in browser | Confirm CORS(app) is in crime_api.py |
| API not reachable | Make sure crime_api.py terminal is still running |
| Prediction returns 0 | Check ngrok URL is correct and still active |

---

## API Reference

### POST /predict

Request body (JSON):
```json
{
  "city": "Delhi",
  "time": "Night",
  "weather": "rainy",
  "cctv": 2,
  "police": 1,
  "traffic": 7,
  "speed": 15,
  "temp": 32,
  "rainfall": 155,
  "accidents": 3,
  "complaints": 4
}
```

Response:
```json
{
  "predicted_severity": 7.842,
  "risk_level": "HIGH",
  "status": "success"
}
```

### GET /health

Returns API status and number of training rows.

---

## Architecture

```
Your PC (always running)
├── crime_api.py
│   ├── Flask API  → localhost:7860/predict
│   ├── ngrok      → abc123.ngrok-free.app/predict (public)
│   └── Gradio UI  → localhost:7861 + gradio.live (public)

Netlify (cloud hosted)
└── crime_analysis_dashboard.html
    └── calls → abc123.ngrok-free.app/predict
```
