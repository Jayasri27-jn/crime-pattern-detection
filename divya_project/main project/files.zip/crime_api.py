import gradio as gr
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import threading
import os
from pyngrok import ngrok

# ─── FLASK APP ────────────────────────────────────────────────────────────────
app = Flask(__name__)
CORS(app)  # Allow all origins so your Netlify dashboard can call this

# ─── LOAD DATASET & TRAIN MODEL ───────────────────────────────────────────────
CITIES   = ['Delhi','Mumbai','Bangalore','Chennai','Kolkata','Hyderabad','Ahmedabad','Pune']
TIMES    = ['Morning','Afternoon','Evening','Night','Midnight']
WEATHERS = ['sunny','cloudy','rainy','foggy','stormy']

le_city    = LabelEncoder().fit(CITIES)
le_time    = LabelEncoder().fit(TIMES)
le_weather = LabelEncoder().fit(WEATHERS)

def load_data():
    csv_path = 'crime_dataset.csv'
    if os.path.exists(csv_path):
        print(f"✅ Loading dataset from {csv_path}")
        df = pd.read_csv(csv_path)
        # Rename columns to standard names if needed
        rename_map = {
            # Add your actual column names on the left if they differ
            'City':                   'city',
            'Time_of_Day':            'time',
            'Weather_Condition':      'weather',
            'Nearby_CCTV_Cameras':    'cctv',
            'Police_Stations_Nearby': 'police',
            'Traffic_Congestion':     'traffic',
            'Traffic_Avg_Speed':      'speed',
            'Temperature':            'temp',
            'Rainfall':               'rainfall',
            'Road_Accidents':         'accidents',
            'Public_Complaints':      'complaints',
            'Crime_Severity':         'severity',
        }
        df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})
        print(f"✅ Dataset loaded: {len(df)} rows")
        return df
    else:
        print("⚠️  crime_dataset.csv not found — using synthetic sample data")
        np.random.seed(42)
        n = 1000
        df = pd.DataFrame({
            'city':       np.random.choice(CITIES, n),
            'time':       np.random.choice(TIMES, n),
            'weather':    np.random.choice(WEATHERS, n),
            'cctv':       np.random.randint(0, 10, n),
            'police':     np.random.randint(0, 5, n),
            'traffic':    np.random.randint(1, 10, n),
            'speed':      np.random.randint(5, 80, n),
            'temp':       np.random.randint(15, 45, n),
            'rainfall':   np.random.randint(0, 300, n),
            'accidents':  np.random.randint(0, 10, n),
            'complaints': np.random.randint(0, 10, n),
            'severity':   np.random.uniform(1, 10, n),
        })
        return df

def encode_df(df):
    d = df.copy()
    d['city']    = le_city.transform(d['city'])
    d['time']    = le_time.transform(d['time'])
    d['weather'] = le_weather.transform(d['weather'])
    return d

data  = load_data()
FEATURES = ['city','time','weather','cctv','police','traffic','speed','temp','rainfall','accidents','complaints']
X = encode_df(data[FEATURES])
y = data['severity']

model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
model.fit(X, y)
print("✅ Model trained successfully\n")

# ─── CORE PREDICTION FUNCTION ─────────────────────────────────────────────────
def predict(city, time, weather, cctv, police, traffic, speed, temp, rainfall, accidents, complaints):
    try:
        row = pd.DataFrame([{
            'city': city, 'time': time, 'weather': weather.lower(),
            'cctv': int(cctv), 'police': int(police), 'traffic': int(traffic),
            'speed': int(speed), 'temp': int(temp), 'rainfall': int(rainfall),
            'accidents': int(accidents), 'complaints': int(complaints),
        }])
        row_enc = encode_df(row)
        score   = float(np.clip(model.predict(row_enc)[0], 1, 10))
        score   = round(score, 3)
        risk    = 'CRITICAL' if score >= 8 else 'HIGH' if score >= 6 else 'MEDIUM' if score >= 4 else 'LOW'
        return score, risk
    except Exception as e:
        return 0.0, f"Error: {e}"

# ─── FLASK ROUTES ─────────────────────────────────────────────────────────────
@app.route('/predict', methods=['POST', 'OPTIONS'])
def api_predict():
    if request.method == 'OPTIONS':
        res = jsonify({})
        res.headers['Access-Control-Allow-Origin']  = '*'
        res.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        res.headers['Access-Control-Allow-Methods'] = 'POST'
        return res
    d = request.get_json()
    score, risk = predict(
        city=d.get('city','Delhi'), time=d.get('time','Morning'),
        weather=d.get('weather','sunny'), cctv=d.get('cctv',2),
        police=d.get('police',1), traffic=d.get('traffic',2),
        speed=d.get('speed',25), temp=d.get('temp',32),
        rainfall=d.get('rainfall',0), accidents=d.get('accidents',2),
        complaints=d.get('complaints',2),
    )
    return jsonify({'predicted_severity': score, 'risk_level': risk, 'status': 'success'})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'online', 'model': 'RandomForest', 'rows_trained': len(data)})

@app.route('/', methods=['GET'])
def index():
    return jsonify({'message': 'Crime Severity API is running', 'endpoints': ['/predict (POST)', '/health (GET)']})

# ─── GRADIO UI ────────────────────────────────────────────────────────────────
def gradio_predict(city, time, weather, cctv, police, traffic, speed, temp, rainfall, accidents, complaints):
    score, risk = predict(city, time, weather, cctv, police, traffic, speed, temp, rainfall, accidents, complaints)
    return score, risk

gradio_app = gr.Interface(
    fn=gradio_predict,
    inputs=[
        gr.Dropdown(choices=CITIES,   value='Delhi',   label='City'),
        gr.Dropdown(choices=TIMES,    value='Morning', label='Time of Day'),
        gr.Dropdown(choices=WEATHERS, value='sunny',   label='Weather Condition'),
        gr.Number(value=2,  label='Nearby CCTV Cameras'),
        gr.Number(value=1,  label='Police Stations Nearby'),
        gr.Number(value=2,  label='Traffic Congestion Level (1-10)'),
        gr.Number(value=25, label='Traffic Avg Speed (KMH)'),
        gr.Number(value=32, label='Temperature (°C)'),
        gr.Number(value=0,  label='Rainfall (mm)'),
        gr.Number(value=2,  label='Road Accidents Reported'),
        gr.Number(value=2,  label='Public Complaints'),
    ],
    outputs=[
        gr.Number(label='Predicted Crime Severity (1-10)'),
        gr.Text(label='Risk Level'),
    ],
    title='🚔 Crime Severity Prediction',
    description='Crime Pattern Detection using Geospatial and Temporal Analysis',
)

# ─── LAUNCH ───────────────────────────────────────────────────────────────────
def run_flask():
    app.run(host='0.0.0.0', port=7860, debug=False, use_reloader=False)

if __name__ == '__main__':
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    print('✅ Flask API  → http://localhost:7860')
    print('✅ API Endpoint → http://localhost:7860/predict\n')

    public_url = ngrok.connect(7860)
    print(f'🌐 PUBLIC URL  → {public_url}')
    print(f'📌 Paste this into your dashboard API Endpoint field:')
    print(f'   {public_url}/predict\n')

    gradio_app.launch(server_name='0.0.0.0', server_port=7861, share=True)
